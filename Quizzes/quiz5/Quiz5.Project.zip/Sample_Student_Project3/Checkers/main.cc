

#include "colors.h"
#include "game.h"
#include "checkers.h"
#include "space.h"

using namespace main_savitch_14;

int main()
{
    checkers test;
    test.play();
    return 0;
}